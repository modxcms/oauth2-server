<?php

$xpdo_meta_map = array (
  'xPDOObject' => 
  array (
    0 => 'OAuth2ServerClients',
    1 => 'OAuth2ServerAccessTokens',
    2 => 'OAuth2ServerAuthorizationCodes',
    3 => 'OAuth2ServerRefreshTokens',
    4 => 'OAuth2ServerScopes',
    5 => 'OAuth2ServerJwt',
  ),
);