<?php
/**
 * @package oauth2server
 */
class OAuth2ServerRefreshTokens extends xPDOObject {}
?>