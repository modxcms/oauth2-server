<?php
/**
 * @package oauth2server
 */
class OAuth2ServerAuthorizationCodes extends xPDOObject {}
?>