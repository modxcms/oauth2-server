<?php
/**
 * @package oauth2server
 */
class OAuth2ServerJwt extends xPDOObject {}
?>