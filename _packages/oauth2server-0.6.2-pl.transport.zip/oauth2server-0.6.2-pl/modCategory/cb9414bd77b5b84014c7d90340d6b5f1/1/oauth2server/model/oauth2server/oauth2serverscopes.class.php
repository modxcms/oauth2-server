<?php
/**
 * @package oauth2server
 */
class OAuth2ServerScopes extends xPDOObject {}
?>