<?php
/**
 * @package oauth2server
 */
class OAuth2ServerClients extends xPDOObject {}
?>